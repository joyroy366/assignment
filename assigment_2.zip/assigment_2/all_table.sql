-- Active: 1768364067203@@127.0.0.1@3306@assigment
CREATE DATABASE assigment;

CREATE TABLE subscription_plan (
  plan_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  plan_name VARCHAR(100) NOT NULL,
  price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  duration_months INT UNSIGNED NOT NULL,
  features TEXT,
  PRIMARY KEY (plan_id),
  UNIQUE KEY uk_subscription_plan_name (plan_name)
) ENGINE=InnoDB;

CREATE TABLE vendor (
  vendor_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  business_name VARCHAR(150) NOT NULL,
  contact_person VARCHAR(120) NOT NULL,
  email VARCHAR(150) NOT NULL,
  phone VARCHAR(30),
  address TEXT,
  subscription_plan_id INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (vendor_id),
  UNIQUE KEY uk_vendor_email (email),
  KEY idx_vendor_plan (subscription_plan_id),
  CONSTRAINT fk_vendor_plan
    FOREIGN KEY (subscription_plan_id)
    REFERENCES subscription_plan(plan_id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;


CREATE TABLE category (
  category_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  PRIMARY KEY (category_id),
  UNIQUE KEY uk_category_name (name)
) ENGINE=InnoDB;


CREATE TABLE product (
  product_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  vendor_id INT UNSIGNED NOT NULL,
  name VARCHAR(150) NOT NULL,
  description TEXT,
  price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  stock_quantity INT UNSIGNED NOT NULL DEFAULT 0,
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (product_id),
  UNIQUE KEY uk_vendor_product_name (vendor_id, name),
  KEY idx_product_vendor (vendor_id),
  CONSTRAINT fk_product_vendor
    FOREIGN KEY (vendor_id)
    REFERENCES vendor(vendor_id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;


CREATE TABLE product_category (
  product_id INT UNSIGNED NOT NULL,
  category_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (product_id, category_id),
  KEY idx_pc_category (category_id),
  CONSTRAINT fk_pc_product
    FOREIGN KEY (product_id)
    REFERENCES product(product_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_pc_category
    FOREIGN KEY (category_id)
    REFERENCES category(category_id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;


CREATE TABLE customer (
  customer_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL,
  phone VARCHAR(30),
  address TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (customer_id),
  UNIQUE KEY uk_customer_email (email)
) ENGINE=InnoDB;



CREATE TABLE orders (
  order_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  customer_id INT UNSIGNED NOT NULL,
  order_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  total_amount DECIMAL(12,2) UNSIGNED NOT NULL DEFAULT 0.00,
  status ENUM('pending','processing','shipped','delivered','cancelled') NOT NULL DEFAULT 'pending',
  PRIMARY KEY (order_id),
  KEY idx_orders_customer (customer_id),
  CONSTRAINT fk_orders_customer
    FOREIGN KEY (customer_id)
    REFERENCES customer(customer_id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE order_item (
  order_id INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  quantity INT UNSIGNED NOT NULL,
  unit_price DECIMAL(12,2) UNSIGNED NOT NULL,
  subtotal DECIMAL(12,2) UNSIGNED NOT NULL,
  PRIMARY KEY (order_id, product_id),
  KEY idx_order_item_product (product_id),
  CONSTRAINT fk_oi_order
    FOREIGN KEY (order_id)
    REFERENCES orders(order_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_oi_product
    FOREIGN KEY (product_id)
    REFERENCES product(product_id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;


CREATE TABLE payment (
  payment_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  order_id INT UNSIGNED NOT NULL,
  method ENUM('Card','Bkash','PayPal','Cash on Delivery') NOT NULL,
  amount DECIMAL(12,2) UNSIGNED NOT NULL,
  payment_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status ENUM('pending','completed','failed','refunded') NOT NULL DEFAULT 'pending',
  PRIMARY KEY (payment_id),
  UNIQUE KEY uk_payment_order (order_id),
  CONSTRAINT fk_payment_order
    FOREIGN KEY (order_id)
    REFERENCES orders(order_id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;



 INSERT INTO subscription_plan (plan_name, price, duration_months, features)
VALUES ('Basic', 0.00, 1, 'Starter features')
ON DUPLICATE KEY UPDATE
  price = VALUES(price),
  duration_months = VALUES(duration_months),
  features = VALUES(features);


  INSERT INTO vendor (business_name, contact_person, email, phone, address, subscription_plan_id)
VALUES (
  'SmartTech Ltd.',
  'Rahim Khan',
  'rahim@smarttech.com',
  '017XXXXXXXX',
  'Dhaka, Bangladesh',
  (SELECT plan_id FROM subscription_plan WHERE plan_name = 'Basic' LIMIT 1)
);

INSERT INTO category (name, description)
VALUES ('Electronics', 'Electronic devices and accessories')
ON DUPLICATE KEY UPDATE description = VALUES(description);


START TRANSACTION;
  SET @vendor_id := (SELECT vendor_id FROM vendor WHERE business_name = 'SmartTech Ltd.' LIMIT 1);
  INSERT INTO product (vendor_id, name, description, price, stock_quantity, status)
  VALUES (@vendor_id, 'Laptop', 'High-performance laptop', 75000.00, 10, 'active');
  SET @product_id := LAST_INSERT_ID();
  SET @category_id := (SELECT category_id FROM category WHERE name = 'Electronics' LIMIT 1);
  INSERT INTO product_category (product_id, category_id)
  VALUES (@product_id, @category_id);
COMMIT;


UPDATE product
SET stock_quantity = 15,
    updated_at = CURRENT_TIMESTAMP
WHERE name = 'Laptop'
  AND vendor_id = (SELECT vendor_id FROM vendor WHERE business_name = 'SmartTech Ltd.' LIMIT 1);


DELETE FROM customer
WHERE email = 'oldcustomer@gmail.com';




SELECT
  v.vendor_id,
  v.business_name,
  sp.plan_name,
  sp.price AS plan_price
FROM vendor v
JOIN subscription_plan sp
  ON sp.plan_id = v.subscription_plan_id
ORDER BY v.business_name;


SELECT
  p.name AS product_name,
  p.price,
  p.stock_quantity
FROM product p
JOIN product_category pc ON pc.product_id = p.product_id
JOIN category c ON c.category_id = pc.category_id
WHERE c.name = 'Electronics'
  AND p.status = 'active'
ORDER BY p.name;


SELECT
  o.order_id,
  o.order_date,
  o.total_amount,
  o.status
FROM orders o
JOIN customer c ON c.customer_id = o.customer_id
WHERE c.name = 'Karim Uddin'
ORDER BY o.order_date DESC;


SELECT
  method,
  amount,
  status
FROM payment
WHERE order_id = 1;

SELECT
  p.product_id,
  p.name AS product_name,
  SUM(oi.quantity) AS total_quantity_sold
FROM order_item oi
JOIN orders o ON o.order_id = oi.order_id
JOIN product p ON p.product_id = oi.product_id
WHERE o.status <> 'cancelled'
GROUP BY p.product_id, p.name
ORDER BY total_quantity_sold DESC
LIMIT 5;