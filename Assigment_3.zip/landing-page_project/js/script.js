const hamburger = document.querySelector('.hamburger');
const nav = document.querySelector('.primary-nav');
const backdrop = document.querySelector('.nav-backdrop');
const navLinks = document.querySelectorAll('.primary-nav a');

function closeNav(){
  nav.classList.remove('open');
  hamburger.classList.remove('is-active');
  hamburger.setAttribute('aria-expanded','false');
  backdrop.classList.remove('show');
  document.body.classList.remove('no-scroll');
}
function openNav(){
  nav.classList.add('open');
  hamburger.classList.add('is-active');
  hamburger.setAttribute('aria-expanded','true');
  backdrop.classList.add('show');
  document.body.classList.add('no-scroll');
}
function toggleNav(){
  if(nav.classList.contains('open')) closeNav();
  else openNav();
}

hamburger.addEventListener('click', toggleNav);
backdrop.addEventListener('click', closeNav);
navLinks.forEach(link => link.addEventListener('click', closeNav));

document.addEventListener('keydown', (e)=>{
  if(e.key === 'Escape') closeNav();
});

window.addEventListener('resize', ()=>{
  if(window.innerWidth > 767) closeNav();
});